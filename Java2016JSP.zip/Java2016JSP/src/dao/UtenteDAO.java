package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class UtenteDAO extends BaseDAO {

	int id;
	String username, password;
	String last_login;
	
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public UtenteDAO(int id, String username, String password, String last_login) {
		super();
		this.id = id;
		this.username = username;
		this.password = password;
		this.last_login = last_login;
	}

	public UtenteDAO(){}
	
	public ArrayList<UtenteDAO> elencoUtenti(){
		ArrayList<UtenteDAO> utenti = new ArrayList<>();
		String sql = "select * from utente ";
		
		try{
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery(sql);
			while (rs.next()) {
				
				utenti.add( new UtenteDAO( rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4) ) );

			}
		} 
		catch(SQLException e){e.printStackTrace();}		
		
		
		
		return utenti;
	}
	
	
	public boolean login(String username, String password){
		
		String sql = "select * from utente where username = '"+username+"' and password = '"+password+"'    ";
		
		boolean utenteTrovato = false;
		
		try{
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery(sql);
			while (rs.next()) {
				utenteTrovato = true;
			}
		} 
		catch(SQLException e){e.printStackTrace();}
		
		return utenteTrovato;
	}

	public int registrazione(String username, String password){
		int esitoRegistrazione = 0;
		

		String sql = "insert into utente (username, password) values (?,?)";
		
		try{
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, username);
			ps.setString(2, password);
			esitoRegistrazione = ps.executeUpdate();
		} catch(SQLException e){
			System.out.println("errore sql");
			e.printStackTrace();
		}
		
		return esitoRegistrazione;
		
	}
	
	
}
