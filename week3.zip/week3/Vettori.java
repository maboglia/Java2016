package week3;

import java.util.Arrays;

/**
 * Created by mauro on 20/06/16.
 */
public class Vettori {

    public static void main(String[] args) {

        //---------
        System.out.println("array di primitivi");

        int[] interi = {5,15,10};
        Arrays.sort(interi);

        for (int i = 0; i < interi.length; i++) {
            System.out.println(interi[i]);
        }


        //---------

        System.out.println("array di stringhe");

        String[] stringhe = {"mele","pere", "banane"};
        Arrays.sort(stringhe);
        for (String frutto : stringhe) {

            System.out.println(frutto);

        }


        System.out.println("stabilire una dimensione iniziale");

        int[] interi2 = new int[10];

        for (int i = 0; i < interi2.length; i++) {
            interi2[i] = i * 30;
        }


        for (int valore:interi2) {
            System.out.println(valore);
        }


        System.out.println("copiare un array");
        int[] copia = new int[5];
        System.arraycopy(interi2, 5, copia, 0, 5);



        for (int valore:copia) {
            System.out.println(valore);
        }

    }


}
