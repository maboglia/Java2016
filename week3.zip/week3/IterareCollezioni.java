package week3;

import java.util.*;

/**
 * Created by mauro on 22/06/16.
 */
public class IterareCollezioni {

    public static void main(String[] args) {

        System.out.println("ordina dati");

        List<String> list = new ArrayList<>();
        list.add("torino");
        list.add("milano");
        list.add("napoli");


        System.out.println("toString()");
        System.out.println(list);
        System.out.println();

        Collections.sort(list);

        System.out.println("toString()");
        System.out.println(list);
        System.out.println();

        System.out.println("Iteratore di liste");

        //Iteratore di liste
        Iterator<String> iterator = list.iterator();
        while (iterator.hasNext()){
            String val = iterator.next();
            System.out.println(val);
        }

        System.out.println("foreach");
        for (String val: list
             ) {
            System.out.println(val);
        }

        System.out.println("foreach di java8, lambda functions");
        list.forEach(System.out::println);


        System.out.println("mappa dati non ordinati");

        Map<String, String> mappa = new HashMap<>();
        mappa.put("Piemonte", "Torino");
        mappa.put("Lombardia", "Milano");
        mappa.put("Campania", "Napoli");
        mappa.put("Puglia", "Bari");


        System.out.println(mappa);
        System.out.println();

        System.out.println("iterare mappe");
        Set<String> keys = mappa.keySet();

        Iterator<String> iterator1 = keys.iterator();

        while (iterator1.hasNext()){
            String key = iterator1.next();
            System.out.println("il capoluogo della regione: " + key + " è " + mappa.get(key));



        }


        for (String key : keys
             ) {
            System.out.println("il capoluogo della regione: " + key + " è " + mappa.get(key));
        }


    }

}
