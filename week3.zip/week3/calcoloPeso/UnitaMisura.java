package week3.calcoloPeso;

/**
 * Created by mauro on 22/06/16.
 */
public class UnitaMisura {

    public final static int CALORIE_X_LIBBRA = 19;
    public final static double LIBBRE_X_KG = 2.2;

}
