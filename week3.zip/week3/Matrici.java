package week3;



/**
 * Created by mauro on 22/06/16.
 */
public class Matrici {

    public static void main(String[] args) {

        String[][] regioni = new String [3][2];

        regioni[0][0] = "Piemonte";
        regioni[0][1] = "Torino";

        regioni[1][0] = "Lombardia";
        regioni[1][1] = "Milano";

        regioni[2][0] = "Toscana";
        regioni[2][1] = "Firenze";

            StringBuilder sb = new StringBuilder();

        for (int i = 0; i < regioni.length ; i++) {

            sb.append("Il capoluogo della Regione ")
                    .append(regioni[i][0])
                    .append(" è ")
                    .append(regioni[i][1])
                    .append(".\n");


        }

        System.out.println(sb);
    }



}
