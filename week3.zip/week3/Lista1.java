package week3;

import java.util.ArrayList;
import java.util.List;

public class Lista1 {


    public static void main(String[] args) {


    //ArrayList<String> regioni = new ArrayList<>();
    List<String> regioni = new ArrayList<>();

    regioni.add("Piemonte");
    regioni.add("Lombardia");
    regioni.add("Campania");

        System.out.println(regioni);

    regioni.add("Toscana");
        System.out.println(regioni);

    regioni.remove(1);
        System.out.println(regioni);

    String s = regioni.get(1);
        System.out.println("ora la seconda regione è: "+s);

        int pos = regioni.indexOf("Campania");
        int totale = regioni.size();
        System.out.println("la Campania è la posizione n.  " + pos + "su un totale di " + totale);

        for (int i = 0; i < regioni.size(); i++) {
            System.out.println(regioni.get(i));
        }

        for (String r : regioni
             ) {
            System.out.println(r.toString());
        }


    }

}
