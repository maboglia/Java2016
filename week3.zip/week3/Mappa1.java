package week3;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by mauro on 22/06/16.
 */
public class Mappa1 {

    public static void main(String[] args) {
        Map<String, String> mappa = new HashMap<>();

        mappa.put("Piemonte", "Torino");
        mappa.put("Lombardia", "Mialno");
        mappa.put("Campania", "Napoli");

        System.out.println(mappa);

        mappa.put("Veneto", "Venezia");
        System.out.println(mappa);

        String capPiemonte = mappa.get("Piemonte");
        System.out.println(capPiemonte);

        mappa.remove("Veneto");
        System.out.println(mappa);

    }

}
