<?php error_reporting(E_ERROR | E_WARNING | E_PARSE); ?>

<?php include 'header.php'; ?>


<?php include 'content.php'; ?>


<?php include 'footer.php'; ?>


