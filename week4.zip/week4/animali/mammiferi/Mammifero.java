package week4.animali.mammiferi;

/**
 * Created by mauro on 30/06/16.
 */
public interface Mammifero {

    public int partorisce();

    public String emetteSuoni();



}
