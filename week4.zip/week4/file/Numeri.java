package week4.file;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

/**
 * Created by mauro on 27/06/16.
 *
 *
 *
 * Scrivi un programma che che legga dei numeri inseriti in un file di testo.
 *
 Se nel file di testo non vi è niente,
 il programma deve avvisare che il file è vuoto,

 se vi è un solo numero,  questo numero deve essere stampato,

 se vi sono due numeri (disposti su due righe differenti) deve essere stampato il loro prodotto,

 se vi sono più di due numeri (disposti su righe differenti) deve essere stampata la loro somma.



 *
 *
 *
 */
public class Numeri {

    public static void main(String[] args) {

        BufferedReader f = null;

        int tot= 0;

        String s = "";

        ArrayList<String> al = new ArrayList<>();

        try {
            f = new BufferedReader(new FileReader("numeri.txt"));
            while (s!=null){
                s=f.readLine();
                if(s!=null){
                    al.add(s);
                }//chiude if
            }//chiude while
            f.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        //ritorna il contenuto di arraylist
        for (String prova : al
             ) {
            System.out.println(prova);
        }
        //ritorno la dimensione di arraylist
        System.out.println(al.size());


        int numeroRighe = al.size();

        switch (numeroRighe){

            case 0:
                System.out.println("il file è vuoto");
             break;

            case 1:
                System.out.println("il file contiene il numero " + al.get(0) );
             break;

            case 2:
                int n1 = Integer.parseInt(al.get(0));
                int n2 = Integer.parseInt(al.get(1));

                System.out.println("il prodotto delle prime 2 righe è: " + (n1 * n2));
             break;

            default:

                for (int e = 0; e<al.size();e++ ) {

                    tot += Integer.parseInt(al.get(e));

                }
                System.out.println("La somma di tutti gli elementi è: " + tot);
                break;


        }



    }


}
