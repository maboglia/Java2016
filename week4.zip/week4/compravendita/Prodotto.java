package week4.compravendita;

/**
 * Created by mauro on 30/06/16.
 */
public class Prodotto {
    private String nome;
    private double prezzo;

    public Prodotto (String n, double p) {
        nome = n;
        prezzo = p;
    }

    public String getNome() {
        return nome;
    }

    public double getPrezzo() {
        return prezzo;
    }

}
