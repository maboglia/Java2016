package week4.classiprime;

import javax.swing.*;

/**
 * Created by mauro on 30/06/16.
 */
public class ClassiPrime {

    public static void main(String[] args) {

        int ac = 2016, an = 0, conta = 0, classi = 0, n = 0, i = 0;

        String s = new String();

        JOptionPane.showMessageDialog(null, "Calcolare il numero di classi prime", "Programma Classi Prime", JOptionPane.PLAIN_MESSAGE);

        s = JOptionPane.showInputDialog("Inserisci il numero complessivo di allievi");

        try {
            n = Integer.parseInt(s);
        } catch (NumberFormatException e) {

            JOptionPane.showMessageDialog(null, "Mi dispiace, qualcosa non funziona!" + e, "Programma Classi Prime", JOptionPane.ERROR_MESSAGE );

            System.exit(-1);
        }

        for (i = 1; i <= n; i++) {
            s = JOptionPane.showInputDialog("Inserisci anno di nascita");

            try  {
                an=Integer.parseInt(s);
            }
            catch (NumberFormatException e)
            {
                JOptionPane.showMessageDialog(null, "Mi dispiace, qualcosa non funziona!"+ e, "Progamma Classi prime", JOptionPane.ERROR_MESSAGE );
                System.exit(-1);
            }

            if ((ac - an) == 6){
                conta++;
            }
        }

        classi = conta / 3;
        JOptionPane.showMessageDialog(null, "Il numero di classi prime è: " + classi, "Programma Classi Prime", JOptionPane.PLAIN_MESSAGE);



    }

}
