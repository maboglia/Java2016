package week2;

/**
 * Created by mauro on 13/06/16.
 */
public class NumeriPrimitivi {

    public static void main(String[] args) {

      byte   b = 1;
      short sh = 1;
      int    i = 1; //Integer
      long   l = 1L;

      float  f = 1f;
      double d = 1d;

        System.out.println(Integer.MIN_VALUE);
        System.out.println(Integer.MAX_VALUE);

    }

}
